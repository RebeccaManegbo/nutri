<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'nutri' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'V)P.eo;#h5:_Ss(m5.$7~b|9]hItKUgoCa+K| 9{Cn V[9>.?4WY_-+d[,`,<Qw|' );
define( 'SECURE_AUTH_KEY',  '3j#3f~AEY&H6hF ?B)Z:mq@9$|V:NC$(HGrS]o%J%2;5WwBgZV.T|k0PznHY])=C' );
define( 'LOGGED_IN_KEY',    '1jy^L~wS5[tnR``(6r[,._(65OAdJ<E&[/?&7dxlV22y+r2jM8k83oiR=?Ydi}s#' );
define( 'NONCE_KEY',        '/@WInC&~!~r<2;`c-$=4[aUB%K9[;*hT&E&=S>VWy]YTBBS8IN;1~XE6D6z;(*7O' );
define( 'AUTH_SALT',        '7WB3>pD;_RcE(ns^:2IAYO81]XpNC-:twyL4,I:ZYe!,uvb5077xy=*&jfB#DC.@' );
define( 'SECURE_AUTH_SALT', '/Tc~&EgCe +$/+q:k;9znRFLMpL>){0;_CW:w^9Ho3bPDQx_1qOf]n!n3H&gVlW=' );
define( 'LOGGED_IN_SALT',   '_>,:N4R${G[C2xhTb3!5>/Y]G+)2mK7hlA(Da#W/;Y~;8P&LNsv^c[lxX![*NOD?' );
define( 'NONCE_SALT',       '83 Yxh1x5$5}uCn?UC]:xLH(]X~=EI6t?r0?on8{|{9uJ8{}/s,zvIyoU+g|7h&F' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
